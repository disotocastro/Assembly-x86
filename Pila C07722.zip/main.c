#include <stdio.h>

// Función recursiva para encontrar el MCD de dos números
int mcd(int a, int b) {
    if (b == 0)  // Caso base: si b es 0, a es el MCD
        return a;
    else
        return mcd(b, a % b);  // Llamada recursiva con b y el resto de a dividido b
}

int main() {
    int num1, num2;
    num1 = 25;
    
    printf("Ingrese un numero para encontrar el MCS con 553:\n");
    scanf("%d", &num2);

    // Llamar a la función mcd() y mostrar el resultado
    printf("El MCD de %d y %d es %d.\n", num1, num2, mcd(num1, num2));

    return 0;
}