/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_188(unsigned x)
{
    return x + 2445773128U;
}

unsigned getval_116()
{
    return 2488848508U;
}

unsigned addval_219(unsigned x)
{
    return x + 3131097944U;
}

unsigned getval_133()
{
    return 2445773128U;
}

void setval_286(unsigned *p)
{
    *p = 2438526942U;
}

unsigned addval_182(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_383(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_495(unsigned x)
{
    return x + 3281031256U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_322(unsigned x)
{
    return x + 3223374505U;
}

void setval_295(unsigned *p)
{
    *p = 3281046153U;
}

unsigned addval_415(unsigned x)
{
    return x + 3378563721U;
}

unsigned addval_483(unsigned x)
{
    return x + 3767077011U;
}

unsigned addval_323(unsigned x)
{
    return x + 3525367437U;
}

unsigned getval_478()
{
    return 3232028297U;
}

unsigned addval_380(unsigned x)
{
    return x + 2497743176U;
}

void setval_443(unsigned *p)
{
    *p = 3675832713U;
}

void setval_290(unsigned *p)
{
    *p = 2425536905U;
}

unsigned addval_302(unsigned x)
{
    return x + 3682915977U;
}

unsigned addval_253(unsigned x)
{
    return x + 2425542281U;
}

void setval_280(unsigned *p)
{
    *p = 3531915529U;
}

unsigned addval_469(unsigned x)
{
    return x + 3524840073U;
}

unsigned getval_272()
{
    return 3524840073U;
}

unsigned addval_146(unsigned x)
{
    return x + 2430632264U;
}

void setval_488(unsigned *p)
{
    *p = 3523794571U;
}

unsigned addval_112(unsigned x)
{
    return x + 2425471369U;
}

unsigned addval_348(unsigned x)
{
    return x + 3281049225U;
}

unsigned getval_138()
{
    return 3221799305U;
}

unsigned addval_190(unsigned x)
{
    return x + 2425471369U;
}

unsigned getval_209()
{
    return 3224945033U;
}

unsigned getval_416()
{
    return 3269495112U;
}

unsigned getval_496()
{
    return 3225998985U;
}

unsigned addval_379(unsigned x)
{
    return x + 3676359369U;
}

void setval_310(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_155()
{
    return 2447411528U;
}

unsigned getval_386()
{
    return 3677407881U;
}

unsigned addval_347(unsigned x)
{
    return x + 3374367105U;
}

void setval_278(unsigned *p)
{
    *p = 3674786441U;
}

void setval_279(unsigned *p)
{
    *p = 3767093393U;
}

void setval_261(unsigned *p)
{
    *p = 3286272328U;
}

unsigned getval_401()
{
    return 3680556681U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
